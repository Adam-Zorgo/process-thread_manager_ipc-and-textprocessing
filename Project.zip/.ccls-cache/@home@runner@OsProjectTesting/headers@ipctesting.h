#ifndef IPCTESTING_H
#define IPCTESTING_H

void test_ipc_performance();

#endif