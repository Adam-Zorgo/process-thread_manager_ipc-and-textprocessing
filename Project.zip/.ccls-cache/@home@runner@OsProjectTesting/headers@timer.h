#ifndef TIMER_H
#define TIMER_H

double get_execution_time(void (*function)(void));

#endif